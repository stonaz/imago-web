var imageProperties = []
var urlStart="http://www.cflr.beniculturali.it:9001/StyleServer/calcrgn?cat=Imago&img=ruggeri/";
var file="001.jp2";
var urlEnd="&style=default/view.xsl&wid=600&hei=400&browser=win_ie&plugin=false";
var url= urlStart+file+urlEnd;
var thumbStart="http://www.cflr.beniculturali.it/lizardtech/iserv/getthumb?cat=Imago&img=ruggeri/";
var thumbEnd="&oif=jpg&thumbspec=middlebig";
var thumb= thumbStart+file+thumbEnd;
var title
var descr

function createList(listaImmagini){
	//$("#lista").append('<li class="dropdown">');
	//$("#lista").append('<a href="#" class="dropdown-toogle"  data-toggle="dropdown">test<b class="caret" ></b></a>');
	//$("#lista").append('</li>');
	var target = $("#lista");
	var divHtml=''
	//menuImmagini=[];
	for(var i=0;i<listaImmagini.length;i++){
		//menuImmagini[i]={}
		
		var obj = listaImmagini[i];
		for(var key in obj){
			var attrName = key;
			var attrValue = obj[key];
			//alert( attrName+':'+attrValue)
			html=('<li class="dropdown">');
			html+=('<a href="#" class="dropdown-toogle"  data-toggle="dropdown">'+key+'<b class="caret" ></b></a>');
			html+=('<ul class="dropdown-menu" style=overflow:auto;max-height:200px;">');
			//html+=(attrValue);
			var immagini=attrValue;
			for(var x=0;x<immagini.length;x++){
				id=immagini[x].Id;
			//alert (immagini[x].Titolo);
				html+=('<li id="'+id+'" class ="lista" onClick=show('+id+')>');
				html+=('<a href="#">');
				html+=(immagini[x].Titolo);
				html+=('</a></li>');
				imageProperties[id]={};
				imageProperties[id]=immagini[x];
				
			}
			html+=('</li>');
			html+=('</ul>');
			//alert(html)
			divHtml+=html;
			//alert(divHtml);
			}                           
		
        }
	//alert(divHtml);
	$(target).html(divHtml);
}

function show(id){
filename=imageProperties[id].Filename;
$("#titolo").html(imageProperties[id].Titolo);
$("#descrizione").html(imageProperties[id].Descrizione);
changeUrl(filename)
}

function changeUrl(Filename){
url= urlStart+filename+urlEnd;
thumb= thumbStart+filename+thumbEnd;
$("#thumb").attr("src",'');
$('#loading').show();
$("#thumb").attr("src",thumb);
}

function newwindow2() 
            { 

     window.open('http://www.cflr.beniculturali.it:9001/StyleServer/calcrgn?cat=Imago&img=kodak/sma200.jp2&style=default/view.xsl&wid=600&hei=400&browser=win_ie&plugin=false','band','width=640,height=500,resizable=yes'); 
     } 

function newwindow(url) 
     { 
     window.open(url,'brogl','width=640,height=500,resizable=yes'); 
     } 
//Ajax check
    
  $(function() {
    $.ajaxSetup({
        error: function(jqXHR, exception) {
            if (jqXHR.status === 0) {
                alert('Not connect.\n Verify Network.');
            } else if (jqXHR.status == 404) {
                alert('Requested page not found. [404]');
            } else if (jqXHR.status == 500) {
                alert('Internal Server Error [500].');
            } else if (exception === 'parsererror') {
                alert('Requested JSON parse failed.');
            } else if (exception === 'timeout') {
                alert('Time out error.');
            } else if (exception === 'abort') {
                alert('Ajax request aborted.');
            } else {
                alert('Uncaught Error.\n' + jqXHR.responseText);
            }
        }
    });
});
  
 //Get Data
function getData(url) {
var data;
    $.ajax({
        async: false, //thats the trick
        url: url,
        dataType: 'json',
        success: function(response){
        data = response;
        }
        
    });
   // alert(data);
    return data;
}

$('#thumb').load(function() {
$('#loading').hide();
});

function hideCarte() {
$('#Carte').hide();
$('#Presentazione').show();
$('#Presentazione').load('ruggieri.html');
};

function showCarte() {
$('#Presentazione').hide();
$('#Carte').show();
};


// Load #loading layers
// Assuming that the div or any other HTML element has the ID = loading and it contains the necessary loading image.

$('#menu-loading').hide(); //initially hide the loading icon
 
        $('#menu-loading').ajaxStart(function(){
            $(this).show();
            //consolenu-loadinge.log('shown');
        });
        $("#menu-loading").ajaxStop(function(){
            $(this).hide();
            //  console.log('hidden');
        }); 
